"""Ingest local capture files, or inspect verified durable state. No broker/model network access."""
import argparse
from datetime import datetime, timedelta, timezone
import hashlib
import json
from pathlib import Path
import sys

from broker_engine import Engine, MAX_BYTES, read_json, stamp
from durable_store import Store

HERE = Path(__file__).resolve().parent


def policy_hash(reference_bytes):
    digest = hashlib.sha256(reference_bytes)
    for name in ("broker_engine.py", "broker_adapters.py", "durable_store.py", "broker_cli.py"):
        digest.update(name.encode())
        digest.update((HERE / name).read_bytes())
    return digest.hexdigest()


def safe_destinations(database, inputs):
    destinations = [database, database.with_suffix(database.suffix + ".errors.jsonl"),
                    Path(str(database) + "-journal"), Path(str(database) + "-wal"), Path(str(database) + "-shm")]
    for dest in destinations:
        for source in inputs:
            if dest.resolve() == source.resolve() or (dest.exists() and source.exists() and dest.samefile(source)):
                raise ValueError("database/log destination aliases an input")


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("ingest", "report", "verify"))
    parser.add_argument("inputs", nargs="*", type=Path)
    parser.add_argument("--db", required=True, type=Path)
    parser.add_argument("--reference", type=Path, default=HERE / "reference.json")
    args = parser.parse_args(argv)
    if args.command == "ingest" and not args.inputs:
        parser.error("ingest requires at least one capture")
    if args.command != "ingest" and args.inputs:
        parser.error("only ingest accepts inputs")
    try:
        safe_destinations(args.db, [*args.inputs, args.reference])
        if args.command != "ingest" and not args.db.exists():
            raise ValueError("database does not exist; report/verify never create state")
        reference_bytes = args.reference.read_bytes()
        engine = Engine(read_json(reference_bytes))
        events = []
        with Store(args.db, engine, policy_hash(reference_bytes)) as store:
            if args.command == "ingest":
                for path in args.inputs:
                    # Read bounded payload for parsing; oversize is operational and logs no
                    # misleading full-file hash. Inputs must be immutable regular local files.
                    with path.open("rb") as stream:
                        raw = stream.read(MAX_BYTES + 1)
                    if len(raw) > MAX_BYTES:
                        raise ValueError("capture exceeds size limit; no truncated source hash recorded")
                    events.append(store.ingest(raw, path.as_posix()))
            proof = store.verify()
            if args.command == "verify":
                result = proof
            else:
                result = store.report()
                now = datetime.now(timezone.utc)
                result["evaluated_at"] = now.isoformat()
                result["freshness_policy"] = "snapshot older than 24 elapsed hours is stale; not an exchange calendar"
                result["account_freshness"] = [{"broker": a["broker"], "account": a["account"],
                    "state": "FUTURE" if stamp(a["as_of"]) > now else
                             "STALE" if now - stamp(a["as_of"]) > timedelta(days=1) else "RECENT"}
                    for a in result["current"]]
                result["run_events"] = events
                result["verify"] = proof
            print(json.dumps(result, sort_keys=True, indent=2, allow_nan=False))
            return 2 if any(e["status"] == "QUARANTINED" for e in events) else 0
    except Exception as exc:
        # Store failures have durable type-only diagnostics. File/config/alias failures
        # occur before trustworthy destinations exist; make them explicit on stderr.
        print(f"FAIL: {type(exc).__name__}: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
